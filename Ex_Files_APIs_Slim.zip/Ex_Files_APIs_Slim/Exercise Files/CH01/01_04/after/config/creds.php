<?php

$db_host = '127.0.0.1';
$db_name = 'chatter';
$db_user = 'chatter_api';
$db_pass = 'chatter_api';